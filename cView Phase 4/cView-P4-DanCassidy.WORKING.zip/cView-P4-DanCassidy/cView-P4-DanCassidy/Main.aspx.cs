﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace cView_P4_DanCassidy
{
    public partial class Menu : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnRandom_Click(object sender, EventArgs e)
        {
            try
            {
                using (CViewDataEntities db = new CViewDataEntities())
                {
                    db.Database.ExecuteSqlCommand("TRUNCATE TABLE dbo.Business");
                    db.Database.ExecuteSqlCommand("TRUNCATE TABLE dbo.BusinessReset");
                    db.Database.ExecuteSqlCommand("TRUNCATE TABLE dbo.Park");
                    db.Database.ExecuteSqlCommand("TRUNCATE TABLE dbo.ParkReset");
                    db.Database.ExecuteSqlCommand("TRUNCATE TABLE dbo.PublicFacility");
                    db.Database.ExecuteSqlCommand("TRUNCATE TABLE dbo.PublicFacilityReset");

                    db.Database.ExecuteSqlCommand("INSERT INTO dbo.BusinessReset SELECT TOP 50 * FROM dbo.BusinessBase ORDER BY NEWID()");
                    db.Database.ExecuteSqlCommand("INSERT INTO dbo.Business SELECT * FROM dbo.BusinessReset");
                    db.Database.ExecuteSqlCommand("INSERT INTO dbo.ParkReset SELECT TOP 50 * FROM dbo.ParkBase ORDER BY NEWID()");
                    db.Database.ExecuteSqlCommand("INSERT INTO dbo.Park SELECT * FROM dbo.ParkReset");
                    db.Database.ExecuteSqlCommand("INSERT INTO dbo.PublicFacilityReset SELECT TOP 50 * FROM dbo.PublicFacilityBase ORDER BY NEWID()");
                    db.Database.ExecuteSqlCommand("INSERT INTO dbo.PublicFacility SELECT * FROM dbo.PublicFacilityReset");
                }

                lblResult.Text = "Tables have been randomized.";
                lblResult.Visible = true;
                lblError.Visible = false;
            }
            catch
            {
                lblError.Text = "Error: Could not randomize the tables.";
                lblError.Visible = true;
                lblResult.Visible = false;
            }
        }

        protected void btnReset_Click(object sender, EventArgs e)
        {
            try
            {
                using (CViewDataEntities db = new CViewDataEntities())
                {
                    db.Database.ExecuteSqlCommand("TRUNCATE TABLE dbo.Business");
                    db.Database.ExecuteSqlCommand("TRUNCATE TABLE dbo.Park");
                    db.Database.ExecuteSqlCommand("TRUNCATE TABLE dbo.PublicFacility");

                    db.Database.ExecuteSqlCommand("INSERT INTO dbo.Business SELECT * FROM dbo.BusinessReset");
                    db.Database.ExecuteSqlCommand("INSERT INTO dbo.Park SELECT * FROM dbo.ParkReset");
                    db.Database.ExecuteSqlCommand("INSERT INTO dbo.PublicFacility SELECT * FROM dbo.PublicFacilityReset");
                }

                lblResult.Text = "Tables have been reset to their prior randomized states.";
                lblResult.Visible = true;
                lblError.Visible = false;
            }
            catch
            {
                lblError.Text = "Error: Could not reset the tables.";
                lblError.Visible = true;
                lblResult.Visible = false;
            }
        }
    }
}