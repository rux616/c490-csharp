﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace cView_P4_DanCassidy
{
    public partial class Delete : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void ddlItemType_SelectedIndexChanged(object sender, EventArgs e)
        {
            lblError.Visible = false;
            lblResult.Visible = false;

            mViewData.ActiveViewIndex = -1;
            btnDelete.Visible = false;

            switch ((Global.Enums.ItemTypes)ddlItemType.SelectedIndex)
            {
                case Global.Enums.ItemTypes.Business:
                    mViewData.ActiveViewIndex = 0;
                    btnDelete.Visible = true;
                    break;

                case Global.Enums.ItemTypes.Park:
                    mViewData.ActiveViewIndex = 1;
                    btnDelete.Visible = true;
                    break;

                case Global.Enums.ItemTypes.PublicFacility:
                    mViewData.ActiveViewIndex = 2;
                    btnDelete.Visible = true;
                    break;

                default:
                    break;
            }
        }

        protected void btnDelete_Click(object sender, EventArgs e)
        {
            object keyToDelete = null;

            try
            {
                using (CViewDataEntities database = new CViewDataEntities())
                {
                    switch ((Global.Enums.ItemTypes)ddlItemType.SelectedIndex)
                    {
                        case Global.Enums.ItemTypes.Business:
                            if (gViewBusiness.SelectedIndex == -1)
                                return;
                            keyToDelete = gViewBusiness.SelectedDataKey.Value;
                            gViewBusiness.SelectRow(-1);
                            Business businessToDelete = database.Businesses.Find(keyToDelete);
                            database.Businesses.Remove(businessToDelete);
                            break;

                        case Global.Enums.ItemTypes.Park:
                            if (gViewPark.SelectedIndex == -1)
                                return;
                            keyToDelete = gViewPark.SelectedDataKey.Value;
                            gViewPark.SelectRow(-1);
                            Park parkToDelete = database.Parks.Find(keyToDelete);
                            database.Parks.Remove(parkToDelete);
                            break;

                        case Global.Enums.ItemTypes.PublicFacility:
                            if (gViewPublicFacility.SelectedIndex == -1)
                                return;
                            keyToDelete = gViewPublicFacility.SelectedDataKey.Value;
                            gViewPublicFacility.SelectRow(-1);
                            PublicFacility publicFacilityToDelete =
                                database.PublicFacilities.Find(keyToDelete);
                            database.PublicFacilities.Remove(publicFacilityToDelete);
                            break;

                        default:
                            // ... How?
                            return;
                    }

                    database.SaveChanges();
                    mViewData.DataBind();
                }

                lblResult.Text = "Row successfully deleted.";
                lblResult.Visible = true;
                lblError.Visible = false;
            }
            catch
            {
                lblError.Text = "Error: Could not delete the specified row.";
                lblError.Visible = true;
                lblResult.Visible = false;
            }
        }
    }
}