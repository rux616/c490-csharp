﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.SessionState;

namespace cView_P4_DanCassidy
{
    public class Global : System.Web.HttpApplication
    {
        protected void Application_Start(object sender, EventArgs e)
        {
        }

        public static class Enums
        {
            public enum ItemTypes
            {
                Business = 1,
                Park,
                PublicFacility,
            }

            public enum BusinessFields
            {
                Name = 1,
                Type,
                StreetAddress,
                City,
                State,
                Zip,
                Latitude,
                Longitude,
                Phone,
                LicenseNumber,
                LicenseIssueDate,
                LicenseExpirDate,
                LicenseStatus,
                CouncilDistrict
            }

            public enum ParkFields
            {
                Name = 1,
                Type,
                StreetAddress,
                City,
                State,
                Zip,
                Latitude,
                Longitude,
                Phone,
                FeatureBaseball,
                FeatureBasketball,
                FeatureGolf,
                FeatureLargeMPField,
                FeatureTennis,
                FeatureVolleyball
            }

            public enum PublicFacilityFields
            {
                Name = 1,
                Type,
                StreetAddress,
                City,
                State,
                Zip,
                Latitude,
                Longitude,
                Phone
            }

            public enum ComparatorsStrings
            {
                Contain = 1,
                NotContain,
                Equal,
                NotEqual
            }

            public enum ComparatorsNotStrings
            {
                Contain = 1,
                NotContain,
                Equal,
                NotEqual,
                Greater,
                Less,
                GreaterEqual,
                LessEqual
            }
        }

        public static class Strings
        {
            public const string Separator = ":";

            public const string BusinessName = "Business Name";
            public const string ParkName = "Park Name";
            public const string PublicFacilityName = "Public Facility Name";

            public const string BusinessType = "Type of Business";
            public const string ParkType = "Type of Park";
            public const string PublicFacilityType = "Type of Public Facility";

            public const string BusinessKey = "License Number";
            public const string ParkKey = ParkName;
            public const string PublicFacilityKey = PublicFacilityName;
        }

    }
}