﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace cView_P4_DanCassidy
{
    public partial class Add : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void ddlItemType_SelectedIndexChanged(object sender, EventArgs e)
        {
            lblError.Visible = false;
            lblResult.Visible = false;

            mViewBasic.ActiveViewIndex = -1;
            mViewSpecific.ActiveViewIndex = -1;
            btnAdd.Visible = false;

            switch ((Global.Enums.ItemTypes)ddlItemType.SelectedIndex)
            {
                case Global.Enums.ItemTypes.Business:
                    mViewBasic.ActiveViewIndex = 0;
                    mViewSpecific.ActiveViewIndex = 0;
                    lblName.Text = Global.Strings.BusinessName + Global.Strings.Separator;
                    lblType.Text = Global.Strings.BusinessType + Global.Strings.Separator;
                    btnAdd.Visible = true;
                    break;

                case Global.Enums.ItemTypes.Park:
                    mViewBasic.ActiveViewIndex = 0;
                    mViewSpecific.ActiveViewIndex = 1;
                    lblName.Text = Global.Strings.ParkName + Global.Strings.Separator;
                    lblType.Text = Global.Strings.ParkType + Global.Strings.Separator;
                    btnAdd.Visible = true;
                    break;

                case Global.Enums.ItemTypes.PublicFacility:
                    mViewBasic.ActiveViewIndex = 0;
                    mViewSpecific.ActiveViewIndex = -1;
                    lblName.Text = Global.Strings.PublicFacilityName + Global.Strings.Separator;
                    lblType.Text = Global.Strings.PublicFacilityType + Global.Strings.Separator;
                    btnAdd.Visible = true;
                    break;

                default:
                    break;
            }
        }

        protected void btnAdd_Click(object sender, EventArgs e)
        {
            object toAdd = null;

            switch ((Global.Enums.ItemTypes)ddlItemType.SelectedIndex)
            {
                case Global.Enums.ItemTypes.Business:
                    toAdd = new Business()
                    {
                        // Common Fields
                        Name = txtName.Text.Trim(),
                        Type = txtType.Text.Trim(),
                        StreetAddress = txtStreetAddress.Text.Trim(),
                        City = txtCity.Text.Trim(),
                        State = txtState.Text.Trim(),
                        Zip = txtZip.Text.Trim(),
                        Latitude = SimpleConvert.ToDecimalN(txtLatitude.Text.Trim()),
                        Longitude = SimpleConvert.ToDecimalN(txtLongitude.Text.Trim()),
                        Phone = txtPhone.Text.Trim(),

                        // Business Fields
                        LicenseNumber = txtLicenseNumber.Text.Trim(),
                        LicenseIssueDate = SimpleConvert.ToDateTimeN(
                            txtLicenseExpirDate.Text.Trim()),
                        LicenseExpirDate = SimpleConvert.ToDateTimeN(
                            txtLicenseExpirDate.Text.Trim()),
                        LicenseStatus = txtLicenseStatus.Text.Trim(),
                        CouncilDistrict = txtCouncilDistrict.Text.Trim()
                    };
                    break;

                case Global.Enums.ItemTypes.Park:
                    toAdd = new Park()
                    {
                        // Common Fields
                        Name = txtName.Text.Trim(),
                        Type = txtType.Text.Trim(),
                        StreetAddress = txtStreetAddress.Text.Trim(),
                        City = txtCity.Text.Trim(),
                        State = txtState.Text.Trim(),
                        Zip = txtZip.Text.Trim(),
                        Latitude = SimpleConvert.ToDecimalN(txtLatitude.Text.Trim()),
                        Longitude = SimpleConvert.ToDecimalN(txtLongitude.Text.Trim()),
                        Phone = txtPhone.Text.Trim(),

                        // Park Fields
                        FeatureBaseball = SimpleConvert.ToByteN(txtFeatureBaseball.Text.Trim()),
                        FeatureBasketball = SimpleConvert.ToDecimalN(
                            txtFeatureBasketball.Text.Trim()),
                        FeatureGolf = SimpleConvert.ToDecimalN(txtFeatureGolf.Text.Trim()),
                        FeatureLargeMPField = SimpleConvert.ToByteN(
                            txtFeatureLargeMPField.Text.Trim()),
                        FeatureTennis = SimpleConvert.ToByteN(txtFeatureTennis.Text.Trim()),
                        FeatureVolleyball = SimpleConvert.ToByteN(txtFeatureVolleyball.Text.Trim())
                    };
                    break;

                case Global.Enums.ItemTypes.PublicFacility:
                    toAdd = new PublicFacility()
                    {
                        // Common Fields
                        Name = txtName.Text.Trim(),
                        Type = txtType.Text.Trim(),
                        StreetAddress = txtStreetAddress.Text.Trim(),
                        City = txtCity.Text.Trim(),
                        State = txtState.Text.Trim(),
                        Zip = txtZip.Text.Trim(),
                        Latitude = SimpleConvert.ToDecimalN(txtLatitude.Text.Trim()),
                        Longitude = SimpleConvert.ToDecimalN(txtLongitude.Text.Trim()),
                        Phone = txtPhone.Text.Trim()
                    };
                    break;

                default:
                    // ... How?
                    return;
            }

            if (toAdd != null)
            {
                try
                {
                    using (CViewDataEntities database = new CViewDataEntities())
                    {
                        if (toAdd is Business)
                        {
                            Business businessToAdd = toAdd as Business;

                            //Do error-checking.
                            if (businessToAdd.LicenseNumber == string.Empty ||
                                businessToAdd.LicenseNumber == null)
                            {
                                throw new Exceptions.EmptyOrNullPKException(
                                    Global.Strings.BusinessKey);
                            }
                            else if (database.Businesses.Find(businessToAdd.LicenseNumber) != null)
                            {
                                throw new Exceptions.DuplicatePKException(
                                    Global.Strings.BusinessKey, businessToAdd.LicenseNumber);
                            }

                            // If everything is ok, add item to table.
                            database.Businesses.Add(businessToAdd);
                        }
                        else if (toAdd is Park)
                        {
                            Park parkToAdd = toAdd as Park;

                            //Do error-checking.
                            if (parkToAdd.Name == string.Empty ||
                                parkToAdd.Name == null)
                            {
                                throw new Exceptions.EmptyOrNullPKException(
                                    Global.Strings.ParkKey);
                            }
                            else if (database.Businesses.Find(parkToAdd.Name) != null)
                            {
                                throw new Exceptions.DuplicatePKException(
                                    Global.Strings.ParkKey, parkToAdd.Name);
                            }

                            // If everything is ok, add item to table.
                            database.Parks.Add(parkToAdd);
                        }
                        else if (toAdd is PublicFacility)
                        {
                            PublicFacility publicFacilityToAdd = toAdd as PublicFacility;

                            //Do error-checking.
                            if (publicFacilityToAdd.Name == string.Empty ||
                                publicFacilityToAdd.Name == null)
                            {
                                throw new Exceptions.EmptyOrNullPKException(
                                    Global.Strings.PublicFacilityKey);
                            }
                            else if (database.Businesses.Find(publicFacilityToAdd.Name) != null)
                            {
                                throw new Exceptions.DuplicatePKException(
                                    Global.Strings.PublicFacilityKey, publicFacilityToAdd.Name);
                            }

                            // If everything is ok, add item to table.
                            database.PublicFacilities.Add(publicFacilityToAdd);
                        }
                        database.SaveChanges();

                        lblResult.Text = "Added record to the table.";
                        lblResult.Visible = true;
                        lblError.Visible = false;
                    }
                }
                catch (Exception ex)
                {
                    // Drill down to the innermost exception.
                    while (ex.InnerException != null)
                        ex = ex.InnerException;

                    lblError.Text = "Error: " + ex.Message;
                    lblError.Visible = true;
                    lblResult.Visible = false;
                }
            }
        }
    }
}