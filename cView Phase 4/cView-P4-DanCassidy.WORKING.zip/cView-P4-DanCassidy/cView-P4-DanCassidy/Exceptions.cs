﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace cView_P4_DanCassidy
{
    public class Exceptions
    {
        [Serializable]
        public class DuplicatePKException : Exception
        {
            public DuplicatePKException() { }

            public DuplicatePKException(string message)
                : base(message) { }

            public DuplicatePKException(string keyName, object keyValue)
                : base(string.Format("An item already exists with a {0} of {1}.",
                       keyName, keyValue))
            { }

            public DuplicatePKException(string message, Exception inner)
                : base(message, inner) { }

            protected DuplicatePKException(
              System.Runtime.Serialization.SerializationInfo info,
              System.Runtime.Serialization.StreamingContext context)
                : base(info, context) { }
        }

        [Serializable]
        public class EmptyOrNullPKException : Exception
        {
            public EmptyOrNullPKException() { }

            public EmptyOrNullPKException(string keyName)
                : base(string.Format("{0} cannot be empty or null.", keyName))
            { }

            public EmptyOrNullPKException(string message, Exception inner)
                : base(message, inner) { }

            protected EmptyOrNullPKException(
              System.Runtime.Serialization.SerializationInfo info,
              System.Runtime.Serialization.StreamingContext context)
                : base(info, context) { }
        }
    }
}