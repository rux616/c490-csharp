﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace cView_P4_DanCassidy
{
    public partial class Display : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void ddlItemType_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch ((Global.Enums.ItemTypes)ddlItemType.SelectedIndex)
            {
                case Global.Enums.ItemTypes.Business:
                    mViewData.ActiveViewIndex = 0;
                    break;

                case Global.Enums.ItemTypes.Park:
                    mViewData.ActiveViewIndex = 1;
                    break;

                case Global.Enums.ItemTypes.PublicFacility:
                    mViewData.ActiveViewIndex = 2;
                    break;

                default:
                    mViewData.ActiveViewIndex = -1;
                    break;
            }
        }
    }
}