﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace cView_P4_DanCassidy
{
    public partial class Search : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void ddlItemType_SelectedIndexChanged(object sender, EventArgs e)
        {
            lblError.Visible = false;
            lblResult.Visible = false;

            ddlBusiness.Visible = false;
            ddlBusiness.SelectedIndex = 0;
            ddlPark.Visible = false;
            ddlPark.SelectedIndex = 0;
            ddlPublicFacility.Visible = false;
            ddlPublicFacility.SelectedIndex = 0;
            ddlComparatorsStrings.Visible = false;
            ddlComparatorsStrings.SelectedIndex = 0;
            ddlComparatorsNotStrings.Visible = false;
            ddlComparatorsNotStrings.SelectedIndex = 0;

            txtSearch.Visible = false;
            txtSearch.Text = "";
            btnSearch.Visible = false;

            mViewSearchResults.ActiveViewIndex = -1;

            switch ((Global.Enums.ItemTypes)ddlItemType.SelectedIndex)
            {
                case Global.Enums.ItemTypes.Business:
                    ddlBusiness.Visible = true;
                    break;

                case Global.Enums.ItemTypes.Park:
                    ddlPark.Visible = true;
                    break;

                case Global.Enums.ItemTypes.PublicFacility:
                    ddlPublicFacility.Visible = true;
                    break;

                default:
                    break;
            }
        }

        protected void ddlBusiness_SelectedIndexChanged(object sender, EventArgs e)
        {
            lblError.Visible = false;
            lblResult.Visible = false;

            //ddlBusiness.Visible = false;
            //ddlBusiness.SelectedIndex = 0;
            //ddlPark.Visible = false;
            //ddlPark.SelectedIndex = 0;
            //ddlPublicFacility.Visible = false;
            //ddlPublicFacility.SelectedIndex = 0;
            ddlComparatorsStrings.Visible = false;
            ddlComparatorsStrings.SelectedIndex = 0;
            ddlComparatorsNotStrings.Visible = false;
            ddlComparatorsNotStrings.SelectedIndex = 0;

            txtSearch.Visible = false;
            txtSearch.Text = "";
            btnSearch.Visible = false;

            mViewSearchResults.ActiveViewIndex = -1;

            switch ((Global.Enums.BusinessFields)ddlBusiness.SelectedIndex)
            {
                case Global.Enums.BusinessFields.Name:
                case Global.Enums.BusinessFields.Type:
                case Global.Enums.BusinessFields.StreetAddress:
                case Global.Enums.BusinessFields.City:
                case Global.Enums.BusinessFields.State:
                case Global.Enums.BusinessFields.Zip:
                case Global.Enums.BusinessFields.Phone:
                case Global.Enums.BusinessFields.LicenseNumber:
                case Global.Enums.BusinessFields.LicenseStatus:
                case Global.Enums.BusinessFields.CouncilDistrict:
                    ddlComparatorsStrings.Visible = true;
                    break;

                case Global.Enums.BusinessFields.Latitude:
                case Global.Enums.BusinessFields.Longitude:
                case Global.Enums.BusinessFields.LicenseIssueDate:
                case Global.Enums.BusinessFields.LicenseExpirDate:
                    ddlComparatorsNotStrings.Visible = true;
                    break;

                default:
                    ddlComparatorsStrings.Visible = false;
                    ddlComparatorsNotStrings.Visible = false;
                    break;
            }
        }

        protected void ddlPark_SelectedIndexChanged(object sender, EventArgs e)
        {
            lblError.Visible = false;
            lblResult.Visible = false;

            //ddlBusiness.Visible = false;
            //ddlBusiness.SelectedIndex = 0;
            //ddlPark.Visible = false;
            //ddlPark.SelectedIndex = 0;
            //ddlPublicFacility.Visible = false;
            //ddlPublicFacility.SelectedIndex = 0;
            ddlComparatorsStrings.Visible = false;
            ddlComparatorsStrings.SelectedIndex = 0;
            ddlComparatorsNotStrings.Visible = false;
            ddlComparatorsNotStrings.SelectedIndex = 0;

            txtSearch.Visible = false;
            txtSearch.Text = "";
            btnSearch.Visible = false;

            mViewSearchResults.ActiveViewIndex = -1;

            switch ((Global.Enums.ParkFields)ddlPark.SelectedIndex)
            {
                case Global.Enums.ParkFields.Name:
                case Global.Enums.ParkFields.Type:
                case Global.Enums.ParkFields.StreetAddress:
                case Global.Enums.ParkFields.City:
                case Global.Enums.ParkFields.State:
                case Global.Enums.ParkFields.Zip:
                case Global.Enums.ParkFields.Phone:
                    ddlComparatorsStrings.Visible = true;
                    break;

                case Global.Enums.ParkFields.Latitude:
                case Global.Enums.ParkFields.Longitude:
                case Global.Enums.ParkFields.FeatureBaseball:
                case Global.Enums.ParkFields.FeatureBasketball:
                case Global.Enums.ParkFields.FeatureGolf:
                case Global.Enums.ParkFields.FeatureLargeMPField:
                case Global.Enums.ParkFields.FeatureTennis:
                case Global.Enums.ParkFields.FeatureVolleyball:
                    ddlComparatorsNotStrings.Visible = true;
                    break;

                default:
                    break;
            }
        }

        protected void ddlPublicFacility_SelectedIndexChanged(object sender, EventArgs e)
        {
            lblError.Visible = false;
            lblResult.Visible = false;

            //ddlBusiness.Visible = false;
            //ddlBusiness.SelectedIndex = 0;
            //ddlPark.Visible = false;
            //ddlPark.SelectedIndex = 0;
            //ddlPublicFacility.Visible = false;
            //ddlPublicFacility.SelectedIndex = 0;
            ddlComparatorsStrings.Visible = false;
            ddlComparatorsStrings.SelectedIndex = 0;
            ddlComparatorsNotStrings.Visible = false;
            ddlComparatorsNotStrings.SelectedIndex = 0;

            txtSearch.Visible = false;
            txtSearch.Text = "";
            btnSearch.Visible = false;

            mViewSearchResults.ActiveViewIndex = -1;

            switch ((Global.Enums.PublicFacilityFields)ddlPublicFacility.SelectedIndex)
            {
                case Global.Enums.PublicFacilityFields.Name:
                case Global.Enums.PublicFacilityFields.Type:
                case Global.Enums.PublicFacilityFields.StreetAddress:
                case Global.Enums.PublicFacilityFields.City:
                case Global.Enums.PublicFacilityFields.State:
                case Global.Enums.PublicFacilityFields.Zip:
                case Global.Enums.PublicFacilityFields.Phone:
                    ddlComparatorsStrings.Visible = true;
                    break;

                case Global.Enums.PublicFacilityFields.Latitude:
                case Global.Enums.PublicFacilityFields.Longitude:
                    ddlComparatorsNotStrings.Visible = true;
                    break;

                default:
                    break;
            }
        }

        protected void ddlComparatorsStrings_SelectedIndexChanged(object sender, EventArgs e)
        {
            lblError.Visible = false;
            lblResult.Visible = false;

            //ddlBusiness.Visible = false;
            //ddlBusiness.SelectedIndex = 0;
            //ddlPark.Visible = false;
            //ddlPark.SelectedIndex = 0;
            //ddlPublicFacility.Visible = false;
            //ddlPublicFacility.SelectedIndex = 0;
            //ddlComparatorsStrings.Visible = false;
            //ddlComparatorsStrings.SelectedIndex = 0;
            //ddlComparatorsNotStrings.Visible = false;
            //ddlComparatorsNotStrings.SelectedIndex = 0;

            txtSearch.Visible = false;
            txtSearch.Text = "";
            btnSearch.Visible = false;

            mViewSearchResults.ActiveViewIndex = -1;

            switch ((Global.Enums.ComparatorsStrings)ddlComparatorsStrings.SelectedIndex)
            {
                case Global.Enums.ComparatorsStrings.Contain:
                case Global.Enums.ComparatorsStrings.NotContain:
                case Global.Enums.ComparatorsStrings.Equal:
                case Global.Enums.ComparatorsStrings.NotEqual:
                    txtSearch.Visible = true;
                    btnSearch.Visible = true;
                    break;

                default:
                    break;
            }
        }

        protected void ddlComparatorsNotStrings_SelectedIndexChanged(object sender, EventArgs e)
        {
            lblError.Visible = false;
            lblResult.Visible = false;

            //ddlBusiness.Visible = false;
            //ddlBusiness.SelectedIndex = 0;
            //ddlPark.Visible = false;
            //ddlPark.SelectedIndex = 0;
            //ddlPublicFacility.Visible = false;
            //ddlPublicFacility.SelectedIndex = 0;
            //ddlComparatorsStrings.Visible = false;
            //ddlComparatorsStrings.SelectedIndex = 0;
            //ddlComparatorsNotStrings.Visible = false;
            //ddlComparatorsNotStrings.SelectedIndex = 0;

            txtSearch.Visible = false;
            txtSearch.Text = "";
            btnSearch.Visible = false;

            mViewSearchResults.ActiveViewIndex = -1;

            switch ((Global.Enums.ComparatorsNotStrings)ddlComparatorsNotStrings.SelectedIndex)
            {
                case Global.Enums.ComparatorsNotStrings.Contain:
                case Global.Enums.ComparatorsNotStrings.NotContain:
                case Global.Enums.ComparatorsNotStrings.Equal:
                case Global.Enums.ComparatorsNotStrings.NotEqual:
                case Global.Enums.ComparatorsNotStrings.Greater:
                case Global.Enums.ComparatorsNotStrings.Less:
                case Global.Enums.ComparatorsNotStrings.GreaterEqual:
                case Global.Enums.ComparatorsNotStrings.LessEqual:
                    txtSearch.Visible = true;
                    btnSearch.Visible = true;
                    break;

                default:
                    break;
            }
        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            lblError.Visible = false;
            lblResult.Visible = false;

            mViewSearchResults.ActiveViewIndex = -1;

            string toSearchFor = txtSearch.Text.Trim();

            // Conversions because LINQ to Entities is stupid.
            Nullable<byte> toSearchForByte = SimpleConvert.ToByteN(toSearchFor);
            Nullable<DateTime> toSearchForDateTime = SimpleConvert.ToDateTimeN(toSearchFor);
            Nullable<decimal> toSearchForDecimal = SimpleConvert.ToDecimalN(toSearchFor);

            int resultCount = 0;
            int viewToDisplay = -1;
            GridView gViewToDisplay;

            try
            {
                using (CViewDataEntities database = new CViewDataEntities())
                {
                    switch ((Global.Enums.ItemTypes)ddlItemType.SelectedIndex)
                    {
                        case Global.Enums.ItemTypes.Business:
                            viewToDisplay = 0;
                            gViewToDisplay = gViewBusinessResults;
                            switch ((Global.Enums.BusinessFields)ddlBusiness.SelectedIndex)
                            {
                                case Global.Enums.BusinessFields.Name:
                                    switch ((Global.Enums.ComparatorsStrings)ddlComparatorsStrings.
                                        SelectedIndex)
                                    {
                                        case Global.Enums.ComparatorsStrings.Contain:
                                            var searchResults = database.Businesses.
                                                Where(b => b.Name.Contains(toSearchFor));
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsStrings.NotContain:
                                            searchResults = database.Businesses.
                                                Where(b => !b.Name.Contains(toSearchFor));
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsStrings.Equal:
                                            searchResults = database.Businesses.
                                                Where(b => b.Name == toSearchFor);
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsStrings.NotEqual:
                                            searchResults = database.Businesses.
                                                Where(b => b.Name != toSearchFor);
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        default:
                                            throw new InvalidOperationException(
                                                "Invalid string comparator dropdown value.");
                                    }
                                    break;

                                case Global.Enums.BusinessFields.Type:
                                    switch ((Global.Enums.ComparatorsStrings)ddlComparatorsStrings.
                                        SelectedIndex)
                                    {
                                        case Global.Enums.ComparatorsStrings.Contain:
                                            var searchResults = database.Businesses.
                                                Where(b => b.Type.Contains(toSearchFor));
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsStrings.NotContain:
                                            searchResults = database.Businesses.
                                                Where(b => !b.Type.Contains(toSearchFor));
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsStrings.Equal:
                                            searchResults = database.Businesses.
                                                Where(b => b.Type == toSearchFor);
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsStrings.NotEqual:
                                            searchResults = database.Businesses.
                                                Where(b => b.Type != toSearchFor);
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        default:
                                            throw new InvalidOperationException(
                                                "Invalid string comparator dropdown value.");
                                    }
                                    break;

                                case Global.Enums.BusinessFields.StreetAddress:
                                    switch ((Global.Enums.ComparatorsStrings)ddlComparatorsStrings.
                                        SelectedIndex)
                                    {
                                        case Global.Enums.ComparatorsStrings.Contain:
                                            var searchResults = database.Businesses.
                                                Where(b => b.StreetAddress.Contains(toSearchFor));
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsStrings.NotContain:
                                            searchResults = database.Businesses.
                                                Where(b => !b.StreetAddress.Contains(toSearchFor));
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsStrings.Equal:
                                            searchResults = database.Businesses.
                                                Where(b => b.StreetAddress == toSearchFor);
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsStrings.NotEqual:
                                            searchResults = database.Businesses.
                                                Where(b => b.StreetAddress != toSearchFor);
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        default:
                                            throw new InvalidOperationException(
                                                "Invalid string comparator dropdown value.");
                                    }
                                    break;

                                case Global.Enums.BusinessFields.City:
                                    switch ((Global.Enums.ComparatorsStrings)ddlComparatorsStrings.
                                        SelectedIndex)
                                    {
                                        case Global.Enums.ComparatorsStrings.Contain:
                                            var searchResults = database.Businesses.
                                                Where(b => b.City.Contains(toSearchFor));
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsStrings.NotContain:
                                            searchResults = database.Businesses.
                                                Where(b => !b.City.Contains(toSearchFor));
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsStrings.Equal:
                                            searchResults = database.Businesses.
                                                Where(b => b.City == toSearchFor);
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsStrings.NotEqual:
                                            searchResults = database.Businesses.
                                                Where(b => b.City != toSearchFor);
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        default:
                                            throw new InvalidOperationException(
                                                "Invalid string comparator dropdown value.");
                                    }
                                    break;

                                case Global.Enums.BusinessFields.State:
                                    switch ((Global.Enums.ComparatorsStrings)ddlComparatorsStrings.
                                        SelectedIndex)
                                    {
                                        case Global.Enums.ComparatorsStrings.Contain:
                                            var searchResults = database.Businesses.
                                                Where(b => b.State.Contains(toSearchFor));
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsStrings.NotContain:
                                            searchResults = database.Businesses.
                                                Where(b => !b.State.Contains(toSearchFor));
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsStrings.Equal:
                                            searchResults = database.Businesses.
                                                Where(b => b.State == toSearchFor);
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsStrings.NotEqual:
                                            searchResults = database.Businesses.
                                                Where(b => b.State != toSearchFor);
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        default:
                                            throw new InvalidOperationException(
                                                "Invalid string comparator dropdown value.");
                                    }
                                    break;

                                case Global.Enums.BusinessFields.Zip:
                                    switch ((Global.Enums.ComparatorsStrings)ddlComparatorsStrings.
                                        SelectedIndex)
                                    {
                                        case Global.Enums.ComparatorsStrings.Contain:
                                            var searchResults = database.Businesses.
                                                Where(b => b.Zip.Contains(toSearchFor));
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsStrings.NotContain:
                                            searchResults = database.Businesses.
                                                Where(b => !b.Zip.Contains(toSearchFor));
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsStrings.Equal:
                                            searchResults = database.Businesses.
                                                Where(b => b.Zip == toSearchFor);
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsStrings.NotEqual:
                                            searchResults = database.Businesses.
                                                Where(b => b.Zip != toSearchFor);
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        default:
                                            throw new InvalidOperationException(
                                                "Invalid string comparator dropdown value.");
                                    }
                                    break;

                                case Global.Enums.BusinessFields.Phone:
                                    switch ((Global.Enums.ComparatorsStrings)ddlComparatorsStrings.
                                        SelectedIndex)
                                    {
                                        case Global.Enums.ComparatorsStrings.Contain:
                                            var searchResults = database.Businesses.
                                                Where(b => b.Phone.Contains(toSearchFor));
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsStrings.NotContain:
                                            searchResults = database.Businesses.
                                                Where(b => !b.Phone.Contains(toSearchFor));
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsStrings.Equal:
                                            searchResults = database.Businesses.
                                                Where(b => b.Phone == toSearchFor);
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsStrings.NotEqual:
                                            searchResults = database.Businesses.
                                                Where(b => b.Phone != toSearchFor);
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        default:
                                            throw new InvalidOperationException(
                                                "Invalid string comparator dropdown value.");
                                    }
                                    break;

                                case Global.Enums.BusinessFields.LicenseNumber:
                                    switch ((Global.Enums.ComparatorsStrings)ddlComparatorsStrings.
                                        SelectedIndex)
                                    {
                                        case Global.Enums.ComparatorsStrings.Contain:
                                            var searchResults = database.Businesses.
                                                Where(b => b.LicenseNumber.Contains(toSearchFor));
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsStrings.NotContain:
                                            searchResults = database.Businesses.
                                                Where(b => !b.LicenseNumber.Contains(toSearchFor));
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsStrings.Equal:
                                            searchResults = database.Businesses.
                                                Where(b => b.LicenseNumber == toSearchFor);
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsStrings.NotEqual:
                                            searchResults = database.Businesses.
                                                Where(b => b.LicenseNumber != toSearchFor);
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        default:
                                            throw new InvalidOperationException(
                                                "Invalid string comparator dropdown value.");
                                    }
                                    break;

                                case Global.Enums.BusinessFields.LicenseStatus:
                                    switch ((Global.Enums.ComparatorsStrings)ddlComparatorsStrings.
                                        SelectedIndex)
                                    {
                                        case Global.Enums.ComparatorsStrings.Contain:
                                            var searchResults = database.Businesses.
                                                Where(b => b.LicenseStatus.Contains(toSearchFor));
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsStrings.NotContain:
                                            searchResults = database.Businesses.
                                                Where(b => !b.LicenseStatus.Contains(toSearchFor));
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsStrings.Equal:
                                            searchResults = database.Businesses.
                                                Where(b => b.LicenseStatus == toSearchFor);
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsStrings.NotEqual:
                                            searchResults = database.Businesses.
                                                Where(b => b.LicenseStatus != toSearchFor);
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        default:
                                            throw new InvalidOperationException(
                                                "Invalid string comparator dropdown value.");
                                    }
                                    break;

                                case Global.Enums.BusinessFields.CouncilDistrict:
                                    switch ((Global.Enums.ComparatorsStrings)ddlComparatorsStrings.
                                        SelectedIndex)
                                    {
                                        case Global.Enums.ComparatorsStrings.Contain:
                                            var searchResults = database.Businesses.
                                                Where(b => b.CouncilDistrict.Contains(toSearchFor));
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsStrings.NotContain:
                                            searchResults = database.Businesses.
                                                Where(b => !b.CouncilDistrict.
                                                    Contains(toSearchFor));
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsStrings.Equal:
                                            searchResults = database.Businesses.
                                                Where(b => b.CouncilDistrict == toSearchFor);
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsStrings.NotEqual:
                                            searchResults = database.Businesses.
                                                Where(b => b.CouncilDistrict != toSearchFor);
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        default:
                                            throw new InvalidOperationException(
                                                "Invalid string comparator dropdown value.");
                                    }
                                    break;

                                case Global.Enums.BusinessFields.Latitude:
                                    switch ((Global.Enums.ComparatorsNotStrings)
                                        ddlComparatorsNotStrings.SelectedIndex)
                                    {
                                        case Global.Enums.ComparatorsNotStrings.Contain:
                                            var searchResults = database.Businesses.Where(b =>
                                                b.Latitude.ToString().Contains(toSearchFor));
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsNotStrings.NotContain:
                                            searchResults = database.Businesses.Where(b =>
                                                !b.Latitude.ToString().Contains(toSearchFor));
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsNotStrings.Equal:
                                            searchResults = database.Businesses.Where(b =>
                                                b.Latitude == toSearchForDecimal);
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsNotStrings.NotEqual:
                                            searchResults = database.Businesses.Where(b =>
                                                b.Latitude != toSearchForDecimal);
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsNotStrings.Greater:
                                            searchResults = database.Businesses.Where(b =>
                                                b.Latitude > toSearchForDecimal);
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsNotStrings.Less:
                                            searchResults = database.Businesses.Where(b =>
                                                b.Latitude < toSearchForDecimal);
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsNotStrings.GreaterEqual:
                                            searchResults = database.Businesses.Where(b =>
                                                b.Latitude >= toSearchForDecimal);
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsNotStrings.LessEqual:
                                            searchResults = database.Businesses.Where(b =>
                                                b.Latitude <= toSearchForDecimal);
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        default:
                                            throw new InvalidOperationException(
                                                "Invalid non-string comparator dropdown value.");
                                    }
                                    break;

                                case Global.Enums.BusinessFields.Longitude:
                                    switch ((Global.Enums.ComparatorsNotStrings)
                                        ddlComparatorsNotStrings.SelectedIndex)
                                    {
                                        case Global.Enums.ComparatorsNotStrings.Contain:
                                            var searchResults = database.Businesses.Where(b =>
                                                b.Longitude.ToString().Contains(toSearchFor));
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsNotStrings.NotContain:
                                            searchResults = database.Businesses.Where(b =>
                                                !b.Longitude.ToString().Contains(toSearchFor));
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsNotStrings.Equal:
                                            searchResults = database.Businesses.Where(b =>
                                                b.Longitude == toSearchForDecimal);
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsNotStrings.NotEqual:
                                            searchResults = database.Businesses.Where(b =>
                                                b.Longitude != toSearchForDecimal);
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsNotStrings.Greater:
                                            searchResults = database.Businesses.Where(b =>
                                                b.Longitude > toSearchForDecimal);
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsNotStrings.Less:
                                            searchResults = database.Businesses.Where(b =>
                                                b.Longitude < toSearchForDecimal);
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsNotStrings.GreaterEqual:
                                            searchResults = database.Businesses.Where(b =>
                                                b.Longitude >= toSearchForDecimal);
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsNotStrings.LessEqual:
                                            searchResults = database.Businesses.Where(b =>
                                                b.Longitude <= toSearchForDecimal);
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        default:
                                            throw new InvalidOperationException(
                                                "Invalid non-string comparator dropdown value.");
                                    }
                                    break;

                                case Global.Enums.BusinessFields.LicenseIssueDate:
                                    switch ((Global.Enums.ComparatorsNotStrings)
                                        ddlComparatorsNotStrings.SelectedIndex)
                                    {
                                        case Global.Enums.ComparatorsNotStrings.Contain:
                                            var searchResults = database.Businesses.Where(b =>
                                                b.LicenseIssueDate.ToString().
                                                Contains(toSearchFor));
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsNotStrings.NotContain:
                                            searchResults = database.Businesses.Where(b =>
                                                !b.LicenseIssueDate.ToString().
                                                Contains(toSearchFor));
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsNotStrings.Equal:
                                            searchResults = database.Businesses.Where(b =>
                                                b.LicenseIssueDate == toSearchForDateTime);
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsNotStrings.NotEqual:
                                            searchResults = database.Businesses.Where(b =>
                                                b.LicenseIssueDate != toSearchForDateTime);
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsNotStrings.Greater:
                                            searchResults = database.Businesses.Where(b =>
                                                b.LicenseIssueDate > toSearchForDateTime);
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsNotStrings.Less:
                                            searchResults = database.Businesses.Where(b =>
                                                b.LicenseIssueDate < toSearchForDateTime);
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsNotStrings.GreaterEqual:
                                            searchResults = database.Businesses.Where(b =>
                                                b.LicenseIssueDate >= toSearchForDateTime);
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsNotStrings.LessEqual:
                                            searchResults = database.Businesses.Where(b =>
                                                b.LicenseIssueDate <= toSearchForDateTime);
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        default:
                                            throw new InvalidOperationException(
                                                "Invalid non-string comparator dropdown value.");
                                    }
                                    break;

                                case Global.Enums.BusinessFields.LicenseExpirDate:
                                    switch ((Global.Enums.ComparatorsNotStrings)
                                        ddlComparatorsNotStrings.SelectedIndex)
                                    {
                                        case Global.Enums.ComparatorsNotStrings.Contain:
                                            var searchResults = database.Businesses.Where(b =>
                                                b.LicenseExpirDate.ToString().
                                                Contains(toSearchFor));
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsNotStrings.NotContain:
                                            searchResults = database.Businesses.Where(b =>
                                                !b.LicenseExpirDate.ToString().
                                                Contains(toSearchFor));
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsNotStrings.Equal:
                                            searchResults = database.Businesses.Where(b =>
                                                b.LicenseExpirDate == toSearchForDateTime);
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsNotStrings.NotEqual:
                                            searchResults = database.Businesses.Where(b =>
                                                b.LicenseExpirDate != toSearchForDateTime);
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsNotStrings.Greater:
                                            searchResults = database.Businesses.Where(b =>
                                                b.LicenseExpirDate > toSearchForDateTime);
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsNotStrings.Less:
                                            searchResults = database.Businesses.Where(b =>
                                                b.LicenseExpirDate < toSearchForDateTime);
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsNotStrings.GreaterEqual:
                                            searchResults = database.Businesses.Where(b =>
                                                b.LicenseExpirDate >= toSearchForDateTime);
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsNotStrings.LessEqual:
                                            searchResults = database.Businesses.Where(b =>
                                                b.LicenseExpirDate <= toSearchForDateTime);
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        default:
                                            throw new InvalidOperationException(
                                                "Invalid non-string comparator dropdown value.");
                                    }
                                    break;

                                default:
                                    throw new InvalidOperationException(
                                        "Invalid business field dropdown value.");
                            }
                            break;

                        case Global.Enums.ItemTypes.Park:
                            viewToDisplay = 1;
                            gViewToDisplay = gViewParkResults;
                            switch ((Global.Enums.ParkFields)ddlPark.SelectedIndex)
                            {
                                case Global.Enums.ParkFields.Name:
                                    switch ((Global.Enums.ComparatorsStrings)ddlComparatorsStrings.
                                        SelectedIndex)
                                    {
                                        case Global.Enums.ComparatorsStrings.Contain:
                                            var searchResults = database.Parks.
                                                Where(b => b.Name.Contains(toSearchFor));
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsStrings.NotContain:
                                            searchResults = database.Parks.
                                                Where(b => !b.Name.Contains(toSearchFor));
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsStrings.Equal:
                                            searchResults = database.Parks.
                                                Where(b => b.Name == toSearchFor);
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsStrings.NotEqual:
                                            searchResults = database.Parks.
                                                Where(b => b.Name != toSearchFor);
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        default:
                                            throw new InvalidOperationException(
                                                "Invalid string comparator dropdown value.");
                                    }
                                    break;

                                case Global.Enums.ParkFields.Type:
                                    switch ((Global.Enums.ComparatorsStrings)ddlComparatorsStrings.
                                        SelectedIndex)
                                    {
                                        case Global.Enums.ComparatorsStrings.Contain:
                                            var searchResults = database.Parks.
                                                Where(b => b.Type.Contains(toSearchFor));
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsStrings.NotContain:
                                            searchResults = database.Parks.
                                                Where(b => !b.Type.Contains(toSearchFor));
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsStrings.Equal:
                                            searchResults = database.Parks.
                                                Where(b => b.Type == toSearchFor);
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsStrings.NotEqual:
                                            searchResults = database.Parks.
                                                Where(b => b.Type != toSearchFor);
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        default:
                                            throw new InvalidOperationException(
                                                "Invalid string comparator dropdown value.");
                                    }
                                    break;

                                case Global.Enums.ParkFields.StreetAddress:
                                    switch ((Global.Enums.ComparatorsStrings)ddlComparatorsStrings.
                                        SelectedIndex)
                                    {
                                        case Global.Enums.ComparatorsStrings.Contain:
                                            var searchResults = database.Parks.
                                                Where(b => b.StreetAddress.Contains(toSearchFor));
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsStrings.NotContain:
                                            searchResults = database.Parks.
                                                Where(b => !b.StreetAddress.Contains(toSearchFor));
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsStrings.Equal:
                                            searchResults = database.Parks.
                                                Where(b => b.StreetAddress == toSearchFor);
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsStrings.NotEqual:
                                            searchResults = database.Parks.
                                                Where(b => b.StreetAddress != toSearchFor);
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        default:
                                            throw new InvalidOperationException(
                                                "Invalid string comparator dropdown value.");
                                    }
                                    break;

                                case Global.Enums.ParkFields.City:
                                    switch ((Global.Enums.ComparatorsStrings)ddlComparatorsStrings.
                                        SelectedIndex)
                                    {
                                        case Global.Enums.ComparatorsStrings.Contain:
                                            var searchResults = database.Parks.
                                                Where(b => b.City.Contains(toSearchFor));
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsStrings.NotContain:
                                            searchResults = database.Parks.
                                                Where(b => !b.City.Contains(toSearchFor));
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsStrings.Equal:
                                            searchResults = database.Parks.
                                                Where(b => b.City == toSearchFor);
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsStrings.NotEqual:
                                            searchResults = database.Parks.
                                                Where(b => b.City != toSearchFor);
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        default:
                                            throw new InvalidOperationException(
                                                "Invalid string comparator dropdown value.");
                                    }
                                    break;

                                case Global.Enums.ParkFields.State:
                                    switch ((Global.Enums.ComparatorsStrings)ddlComparatorsStrings.
                                        SelectedIndex)
                                    {
                                        case Global.Enums.ComparatorsStrings.Contain:
                                            var searchResults = database.Parks.
                                                Where(b => b.State.Contains(toSearchFor));
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsStrings.NotContain:
                                            searchResults = database.Parks.
                                                Where(b => !b.State.Contains(toSearchFor));
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsStrings.Equal:
                                            searchResults = database.Parks.
                                                Where(b => b.State == toSearchFor);
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsStrings.NotEqual:
                                            searchResults = database.Parks.
                                                Where(b => b.State != toSearchFor);
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        default:
                                            throw new InvalidOperationException(
                                                "Invalid string comparator dropdown value.");
                                    }
                                    break;

                                case Global.Enums.ParkFields.Zip:
                                    switch ((Global.Enums.ComparatorsStrings)ddlComparatorsStrings.
                                        SelectedIndex)
                                    {
                                        case Global.Enums.ComparatorsStrings.Contain:
                                            var searchResults = database.Parks.
                                                Where(b => b.Zip.Contains(toSearchFor));
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsStrings.NotContain:
                                            searchResults = database.Parks.
                                                Where(b => !b.Zip.Contains(toSearchFor));
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsStrings.Equal:
                                            searchResults = database.Parks.
                                                Where(b => b.Zip == toSearchFor);
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsStrings.NotEqual:
                                            searchResults = database.Parks.
                                                Where(b => b.Zip != toSearchFor);
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        default:
                                            throw new InvalidOperationException(
                                                "Invalid string comparator dropdown value.");
                                    }
                                    break;

                                case Global.Enums.ParkFields.Phone:
                                    switch ((Global.Enums.ComparatorsStrings)ddlComparatorsStrings.
                                        SelectedIndex)
                                    {
                                        case Global.Enums.ComparatorsStrings.Contain:
                                            var searchResults = database.Parks.
                                                Where(b => b.Phone.Contains(toSearchFor));
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsStrings.NotContain:
                                            searchResults = database.Parks.
                                                Where(b => !b.Phone.Contains(toSearchFor));
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsStrings.Equal:
                                            searchResults = database.Parks.
                                                Where(b => b.Phone == toSearchFor);
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsStrings.NotEqual:
                                            searchResults = database.Parks.
                                                Where(b => b.Phone != toSearchFor);
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        default:
                                            throw new InvalidOperationException(
                                                "Invalid string comparator dropdown value.");
                                    }
                                    break;

                                case Global.Enums.ParkFields.Latitude:
                                    switch ((Global.Enums.ComparatorsNotStrings)
                                        ddlComparatorsNotStrings.SelectedIndex)
                                    {
                                        case Global.Enums.ComparatorsNotStrings.Contain:
                                            var searchResults = database.Parks.Where(b =>
                                                b.Latitude.ToString().Contains(toSearchFor));
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsNotStrings.NotContain:
                                            searchResults = database.Parks.Where(b =>
                                                !b.Latitude.ToString().Contains(toSearchFor));
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsNotStrings.Equal:
                                            searchResults = database.Parks.Where(b =>
                                                b.Latitude == toSearchForDecimal);
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsNotStrings.NotEqual:
                                            searchResults = database.Parks.Where(b =>
                                                b.Latitude != toSearchForDecimal);
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsNotStrings.Greater:
                                            searchResults = database.Parks.Where(b =>
                                                b.Latitude > toSearchForDecimal);
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsNotStrings.Less:
                                            searchResults = database.Parks.Where(b =>
                                                b.Latitude < toSearchForDecimal);
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsNotStrings.GreaterEqual:
                                            searchResults = database.Parks.Where(b =>
                                                b.Latitude >= toSearchForDecimal);
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsNotStrings.LessEqual:
                                            searchResults = database.Parks.Where(b =>
                                                b.Latitude <= toSearchForDecimal);
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        default:
                                            throw new InvalidOperationException(
                                                "Invalid non-string comparator dropdown value.");
                                    }
                                    break;

                                case Global.Enums.ParkFields.Longitude:
                                    switch ((Global.Enums.ComparatorsNotStrings)
                                        ddlComparatorsNotStrings.SelectedIndex)
                                    {
                                        case Global.Enums.ComparatorsNotStrings.Contain:
                                            var searchResults = database.Parks.Where(b =>
                                                b.Longitude.ToString().Contains(toSearchFor));
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsNotStrings.NotContain:
                                            searchResults = database.Parks.Where(b =>
                                                !b.Longitude.ToString().Contains(toSearchFor));
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsNotStrings.Equal:
                                            searchResults = database.Parks.Where(b =>
                                                b.Longitude == toSearchForDecimal);
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsNotStrings.NotEqual:
                                            searchResults = database.Parks.Where(b =>
                                                b.Longitude != toSearchForDecimal);
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsNotStrings.Greater:
                                            searchResults = database.Parks.Where(b =>
                                                b.Longitude > toSearchForDecimal);
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsNotStrings.Less:
                                            searchResults = database.Parks.Where(b =>
                                                b.Longitude < toSearchForDecimal);
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsNotStrings.GreaterEqual:
                                            searchResults = database.Parks.Where(b =>
                                                b.Longitude >= toSearchForDecimal);
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsNotStrings.LessEqual:
                                            searchResults = database.Parks.Where(b =>
                                                b.Longitude <= toSearchForDecimal);
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        default:
                                            throw new InvalidOperationException(
                                                "Invalid non-string comparator dropdown value.");
                                    }
                                    break;

                                case Global.Enums.ParkFields.FeatureGolf:
                                    switch ((Global.Enums.ComparatorsNotStrings)
                                        ddlComparatorsNotStrings.SelectedIndex)
                                    {
                                        case Global.Enums.ComparatorsNotStrings.Contain:
                                            var searchResults = database.Parks.Where(b =>
                                                b.FeatureGolf.ToString().Contains(toSearchFor));
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsNotStrings.NotContain:
                                            searchResults = database.Parks.Where(b =>
                                                !b.FeatureGolf.ToString().Contains(toSearchFor));
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsNotStrings.Equal:
                                            searchResults = database.Parks.Where(b =>
                                                b.FeatureGolf == toSearchForDecimal);
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsNotStrings.NotEqual:
                                            searchResults = database.Parks.Where(b =>
                                                b.FeatureGolf != toSearchForDecimal);
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsNotStrings.Greater:
                                            searchResults = database.Parks.Where(b =>
                                                b.FeatureGolf > toSearchForDecimal);
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsNotStrings.Less:
                                            searchResults = database.Parks.Where(b =>
                                                b.FeatureGolf < toSearchForDecimal);
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsNotStrings.GreaterEqual:
                                            searchResults = database.Parks.Where(b =>
                                                b.FeatureGolf >= toSearchForDecimal);
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsNotStrings.LessEqual:
                                            searchResults = database.Parks.Where(b =>
                                                b.FeatureGolf <= toSearchForDecimal);
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        default:
                                            throw new InvalidOperationException(
                                                "Invalid non-string comparator dropdown value.");
                                    }
                                    break;

                                case Global.Enums.ParkFields.FeatureBasketball:
                                    switch ((Global.Enums.ComparatorsNotStrings)
                                        ddlComparatorsNotStrings.SelectedIndex)
                                    {
                                        case Global.Enums.ComparatorsNotStrings.Contain:
                                            var searchResults = database.Parks.Where(b =>
                                                b.FeatureBasketball.ToString().
                                                Contains(toSearchFor));
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsNotStrings.NotContain:
                                            searchResults = database.Parks.Where(b =>
                                                !b.FeatureBasketball.ToString().
                                                Contains(toSearchFor));
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsNotStrings.Equal:
                                            searchResults = database.Parks.Where(b =>
                                                b.FeatureBasketball == toSearchForDecimal);
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsNotStrings.NotEqual:
                                            searchResults = database.Parks.Where(b =>
                                                b.FeatureBasketball != toSearchForDecimal);
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsNotStrings.Greater:
                                            searchResults = database.Parks.Where(b =>
                                                b.FeatureBasketball > toSearchForDecimal);
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsNotStrings.Less:
                                            searchResults = database.Parks.Where(b =>
                                                b.FeatureBasketball < toSearchForDecimal);
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsNotStrings.GreaterEqual:
                                            searchResults = database.Parks.Where(b =>
                                                b.FeatureBasketball >= toSearchForDecimal);
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsNotStrings.LessEqual:
                                            searchResults = database.Parks.Where(b =>
                                                b.FeatureBasketball <= toSearchForDecimal);
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        default:
                                            throw new InvalidOperationException(
                                                "Invalid non-string comparator dropdown value.");
                                    }
                                    break;

                                case Global.Enums.ParkFields.FeatureBaseball:
                                    switch ((Global.Enums.ComparatorsNotStrings)
                                        ddlComparatorsNotStrings.SelectedIndex)
                                    {
                                        case Global.Enums.ComparatorsNotStrings.Contain:
                                            var searchResults = database.Parks.Where(b =>
                                                b.FeatureBaseball.ToString().
                                                Contains(toSearchFor));
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsNotStrings.NotContain:
                                            searchResults = database.Parks.Where(b =>
                                                !b.FeatureBaseball.ToString().
                                                Contains(toSearchFor));
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsNotStrings.Equal:
                                            searchResults = database.Parks.Where(b =>
                                                b.FeatureBaseball == toSearchForByte);
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsNotStrings.NotEqual:
                                            searchResults = database.Parks.Where(b =>
                                                b.FeatureBaseball != (toSearchForByte));
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsNotStrings.Greater:
                                            searchResults = database.Parks.Where(b =>
                                                b.FeatureBaseball > toSearchForByte);
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsNotStrings.Less:
                                            searchResults = database.Parks.Where(b =>
                                                b.FeatureBaseball < toSearchForByte);
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsNotStrings.GreaterEqual:
                                            searchResults = database.Parks.Where(b =>
                                                b.FeatureBaseball >= toSearchForByte);
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsNotStrings.LessEqual:
                                            searchResults = database.Parks.Where(b =>
                                                b.FeatureBaseball <= toSearchForByte);
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        default:
                                            throw new InvalidOperationException(
                                                "Invalid non-string comparator dropdown value.");
                                    }
                                    break;

                                case Global.Enums.ParkFields.FeatureLargeMPField:
                                    switch ((Global.Enums.ComparatorsNotStrings)
                                        ddlComparatorsNotStrings.SelectedIndex)
                                    {
                                        case Global.Enums.ComparatorsNotStrings.Contain:
                                            var searchResults = database.Parks.Where(b =>
                                                b.FeatureLargeMPField.ToString().
                                                Contains(toSearchFor));
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsNotStrings.NotContain:
                                            searchResults = database.Parks.Where(b =>
                                                !b.FeatureLargeMPField.ToString().
                                                Contains(toSearchFor));
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsNotStrings.Equal:
                                            searchResults = database.Parks.Where(b =>
                                                b.FeatureLargeMPField == toSearchForByte);
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsNotStrings.NotEqual:
                                            searchResults = database.Parks.Where(b =>
                                                b.FeatureLargeMPField != toSearchForByte);
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsNotStrings.Greater:
                                            searchResults = database.Parks.Where(b =>
                                                b.FeatureLargeMPField > toSearchForByte);
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsNotStrings.Less:
                                            searchResults = database.Parks.Where(b =>
                                                b.FeatureLargeMPField < toSearchForByte);
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsNotStrings.GreaterEqual:
                                            searchResults = database.Parks.Where(b =>
                                                b.FeatureLargeMPField >= toSearchForByte);
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsNotStrings.LessEqual:
                                            searchResults = database.Parks.Where(b =>
                                                b.FeatureLargeMPField <= toSearchForByte);
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        default:
                                            throw new InvalidOperationException(
                                                "Invalid non-string comparator dropdown value.");
                                    }
                                    break;

                                case Global.Enums.ParkFields.FeatureTennis:
                                    switch ((Global.Enums.ComparatorsNotStrings)
                                        ddlComparatorsNotStrings.SelectedIndex)
                                    {
                                        case Global.Enums.ComparatorsNotStrings.Contain:
                                            var searchResults = database.Parks.Where(b =>
                                                b.FeatureTennis.ToString().Contains(toSearchFor));
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsNotStrings.NotContain:
                                            searchResults = database.Parks.Where(b =>
                                                !b.FeatureTennis.ToString().Contains(toSearchFor));
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsNotStrings.Equal:
                                            searchResults = database.Parks.Where(b =>
                                                b.FeatureTennis == toSearchForByte);
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsNotStrings.NotEqual:
                                            searchResults = database.Parks.Where(b =>
                                                b.FeatureTennis != toSearchForByte);
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsNotStrings.Greater:
                                            searchResults = database.Parks.Where(b =>
                                                b.FeatureTennis > toSearchForByte);
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsNotStrings.Less:
                                            searchResults = database.Parks.Where(b =>
                                                b.FeatureTennis < toSearchForByte);
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsNotStrings.GreaterEqual:
                                            searchResults = database.Parks.Where(b =>
                                                b.FeatureTennis >= toSearchForByte);
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsNotStrings.LessEqual:
                                            searchResults = database.Parks.Where(b =>
                                                b.FeatureTennis <= toSearchForByte);
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        default:
                                            throw new InvalidOperationException(
                                                "Invalid non-string comparator dropdown value.");
                                    }
                                    break;

                                case Global.Enums.ParkFields.FeatureVolleyball:
                                    switch ((Global.Enums.ComparatorsNotStrings)
                                        ddlComparatorsNotStrings.SelectedIndex)
                                    {
                                        case Global.Enums.ComparatorsNotStrings.Contain:
                                            var searchResults = database.Parks.Where(b =>
                                                b.FeatureVolleyball.ToString().
                                                Contains(toSearchFor));
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsNotStrings.NotContain:
                                            searchResults = database.Parks.Where(b =>
                                                !b.FeatureVolleyball.ToString().
                                                Contains(toSearchFor));
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsNotStrings.Equal:
                                            searchResults = database.Parks.Where(b =>
                                                b.FeatureVolleyball == toSearchForByte);
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsNotStrings.NotEqual:
                                            searchResults = database.Parks.Where(b =>
                                                b.FeatureVolleyball != toSearchForByte);
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsNotStrings.Greater:
                                            searchResults = database.Parks.Where(b =>
                                                b.FeatureVolleyball > toSearchForByte);
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsNotStrings.Less:
                                            searchResults = database.Parks.Where(b =>
                                                b.FeatureVolleyball < toSearchForByte);
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsNotStrings.GreaterEqual:
                                            searchResults = database.Parks.Where(b =>
                                                b.FeatureVolleyball >= toSearchForByte);
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsNotStrings.LessEqual:
                                            searchResults = database.Parks.Where(b =>
                                                b.FeatureVolleyball <= toSearchForByte);
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        default:
                                            throw new InvalidOperationException(
                                                "Invalid non-string comparator dropdown value.");
                                    }
                                    break;

                                default:
                                    throw new InvalidOperationException(
                                        "Invalid park field dropdown value.");
                            }
                            break;

                        case Global.Enums.ItemTypes.PublicFacility:
                            viewToDisplay = 2;
                            gViewToDisplay = gViewPublicFacilityResults;
                            switch ((Global.Enums.PublicFacilityFields)ddlPublicFacility.
                                SelectedIndex)
                            {
                                case Global.Enums.PublicFacilityFields.Name:
                                    switch ((Global.Enums.ComparatorsStrings)ddlComparatorsStrings.
                                        SelectedIndex)
                                    {
                                        case Global.Enums.ComparatorsStrings.Contain:
                                            var searchResults = database.PublicFacilities.
                                                Where(b => b.Name.Contains(toSearchFor));
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsStrings.NotContain:
                                            searchResults = database.PublicFacilities.
                                                Where(b => !b.Name.Contains(toSearchFor));
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsStrings.Equal:
                                            searchResults = database.PublicFacilities.
                                                Where(b => b.Name == toSearchFor);
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsStrings.NotEqual:
                                            searchResults = database.PublicFacilities.
                                                Where(b => b.Name != toSearchFor);
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        default:
                                            throw new InvalidOperationException(
                                                "Invalid string comparator dropdown value.");
                                    }
                                    break;

                                case Global.Enums.PublicFacilityFields.Type:
                                    switch ((Global.Enums.ComparatorsStrings)ddlComparatorsStrings.
                                        SelectedIndex)
                                    {
                                        case Global.Enums.ComparatorsStrings.Contain:
                                            var searchResults = database.PublicFacilities.
                                                Where(b => b.Type.Contains(toSearchFor));
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsStrings.NotContain:
                                            searchResults = database.PublicFacilities.
                                                Where(b => !b.Type.Contains(toSearchFor));
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsStrings.Equal:
                                            searchResults = database.PublicFacilities.
                                                Where(b => b.Type == toSearchFor);
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsStrings.NotEqual:
                                            searchResults = database.PublicFacilities.
                                                Where(b => b.Type != toSearchFor);
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        default:
                                            throw new InvalidOperationException(
                                                "Invalid string comparator dropdown value.");
                                    }
                                    break;

                                case Global.Enums.PublicFacilityFields.StreetAddress:
                                    switch ((Global.Enums.ComparatorsStrings)ddlComparatorsStrings.
                                        SelectedIndex)
                                    {
                                        case Global.Enums.ComparatorsStrings.Contain:
                                            var searchResults = database.PublicFacilities.
                                                Where(b => b.StreetAddress.Contains(toSearchFor));
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsStrings.NotContain:
                                            searchResults = database.PublicFacilities.
                                                Where(b => !b.StreetAddress.Contains(toSearchFor));
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsStrings.Equal:
                                            searchResults = database.PublicFacilities.
                                                Where(b => b.StreetAddress == toSearchFor);
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsStrings.NotEqual:
                                            searchResults = database.PublicFacilities.
                                                Where(b => b.StreetAddress != toSearchFor);
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        default:
                                            throw new InvalidOperationException(
                                                "Invalid string comparator dropdown value.");
                                    }
                                    break;

                                case Global.Enums.PublicFacilityFields.City:
                                    switch ((Global.Enums.ComparatorsStrings)ddlComparatorsStrings.
                                        SelectedIndex)
                                    {
                                        case Global.Enums.ComparatorsStrings.Contain:
                                            var searchResults = database.PublicFacilities.
                                                Where(b => b.City.Contains(toSearchFor));
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsStrings.NotContain:
                                            searchResults = database.PublicFacilities.
                                                Where(b => !b.City.Contains(toSearchFor));
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsStrings.Equal:
                                            searchResults = database.PublicFacilities.
                                                Where(b => b.City == toSearchFor);
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsStrings.NotEqual:
                                            searchResults = database.PublicFacilities.
                                                Where(b => b.City != toSearchFor);
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        default:
                                            throw new InvalidOperationException(
                                                "Invalid string comparator dropdown value.");
                                    }
                                    break;

                                case Global.Enums.PublicFacilityFields.State:
                                    switch ((Global.Enums.ComparatorsStrings)ddlComparatorsStrings.
                                        SelectedIndex)
                                    {
                                        case Global.Enums.ComparatorsStrings.Contain:
                                            var searchResults = database.PublicFacilities.
                                                Where(b => b.State.Contains(toSearchFor));
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsStrings.NotContain:
                                            searchResults = database.PublicFacilities.
                                                Where(b => !b.State.Contains(toSearchFor));
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsStrings.Equal:
                                            searchResults = database.PublicFacilities.
                                                Where(b => b.State == toSearchFor);
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsStrings.NotEqual:
                                            searchResults = database.PublicFacilities.
                                                Where(b => b.State != toSearchFor);
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        default:
                                            throw new InvalidOperationException(
                                                "Invalid string comparator dropdown value.");
                                    }
                                    break;

                                case Global.Enums.PublicFacilityFields.Zip:
                                    switch ((Global.Enums.ComparatorsStrings)ddlComparatorsStrings.
                                        SelectedIndex)
                                    {
                                        case Global.Enums.ComparatorsStrings.Contain:
                                            var searchResults = database.PublicFacilities.
                                                Where(b => b.Zip.Contains(toSearchFor));
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsStrings.NotContain:
                                            searchResults = database.PublicFacilities.
                                                Where(b => !b.Zip.Contains(toSearchFor));
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsStrings.Equal:
                                            searchResults = database.PublicFacilities.
                                                Where(b => b.Zip == toSearchFor);
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsStrings.NotEqual:
                                            searchResults = database.PublicFacilities.
                                                Where(b => b.Zip != toSearchFor);
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        default:
                                            throw new InvalidOperationException(
                                                "Invalid string comparator dropdown value.");
                                    }
                                    break;

                                case Global.Enums.PublicFacilityFields.Phone:
                                    switch ((Global.Enums.ComparatorsStrings)ddlComparatorsStrings.
                                        SelectedIndex)
                                    {
                                        case Global.Enums.ComparatorsStrings.Contain:
                                            var searchResults = database.PublicFacilities.
                                                Where(b => b.Phone.Contains(toSearchFor));
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsStrings.NotContain:
                                            searchResults = database.PublicFacilities.
                                                Where(b => !b.Phone.Contains(toSearchFor));
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsStrings.Equal:
                                            searchResults = database.PublicFacilities.
                                                Where(b => b.Phone == toSearchFor);
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsStrings.NotEqual:
                                            searchResults = database.PublicFacilities.
                                                Where(b => b.Phone != toSearchFor);
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        default:
                                            throw new InvalidOperationException(
                                                "Invalid string comparator dropdown value.");
                                    }
                                    break;

                                case Global.Enums.PublicFacilityFields.Latitude:
                                    switch ((Global.Enums.ComparatorsNotStrings)
                                        ddlComparatorsNotStrings.SelectedIndex)
                                    {
                                        case Global.Enums.ComparatorsNotStrings.Contain:
                                            var searchResults = database.PublicFacilities.Where(b =>
                                                b.Latitude.ToString().Contains(toSearchFor));
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsNotStrings.NotContain:
                                            searchResults = database.PublicFacilities.Where(b =>
                                                !b.Latitude.ToString().Contains(toSearchFor));
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsNotStrings.Equal:
                                            searchResults = database.PublicFacilities.Where(b =>
                                                b.Latitude == toSearchForDecimal);
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsNotStrings.NotEqual:
                                            searchResults = database.PublicFacilities.Where(b =>
                                                b.Latitude != toSearchForDecimal);
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsNotStrings.Greater:
                                            searchResults = database.PublicFacilities.Where(b =>
                                                b.Latitude > toSearchForDecimal);
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsNotStrings.Less:
                                            searchResults = database.PublicFacilities.Where(b =>
                                                b.Latitude < toSearchForDecimal);
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsNotStrings.GreaterEqual:
                                            searchResults = database.PublicFacilities.Where(b =>
                                                b.Latitude >= toSearchForDecimal);
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsNotStrings.LessEqual:
                                            searchResults = database.PublicFacilities.Where(b =>
                                                b.Latitude <= toSearchForDecimal);
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        default:
                                            throw new InvalidOperationException(
                                                "Invalid non-string comparator dropdown value.");
                                    }
                                    break;

                                case Global.Enums.PublicFacilityFields.Longitude:
                                    switch ((Global.Enums.ComparatorsNotStrings)
                                        ddlComparatorsNotStrings.SelectedIndex)
                                    {
                                        case Global.Enums.ComparatorsNotStrings.Contain:
                                            var searchResults = database.PublicFacilities.Where(b =>
                                                b.Longitude.ToString().Contains(toSearchFor));
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsNotStrings.NotContain:
                                            searchResults = database.PublicFacilities.Where(b =>
                                                !b.Longitude.ToString().Contains(toSearchFor));
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsNotStrings.Equal:
                                            searchResults = database.PublicFacilities.Where(b =>
                                                b.Longitude == toSearchForDecimal);
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsNotStrings.NotEqual:
                                            searchResults = database.PublicFacilities.Where(b =>
                                                b.Longitude != toSearchForDecimal);
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsNotStrings.Greater:
                                            searchResults = database.PublicFacilities.Where(b =>
                                                b.Longitude > toSearchForDecimal);
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsNotStrings.Less:
                                            searchResults = database.PublicFacilities.Where(b =>
                                                b.Longitude < toSearchForDecimal);
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsNotStrings.GreaterEqual:
                                            searchResults = database.PublicFacilities.Where(b =>
                                                b.Longitude >= toSearchForDecimal);
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        case Global.Enums.ComparatorsNotStrings.LessEqual:
                                            searchResults = database.PublicFacilities.Where(b =>
                                                b.Longitude <= toSearchForDecimal);
                                            resultCount = searchResults.Count();
                                            gViewToDisplay.DataSource = searchResults.ToList();
                                            break;

                                        default:
                                            throw new InvalidOperationException(
                                                "Invalid non-string comparator dropdown value.");
                                    }
                                    break;

                                default:
                                    throw new InvalidOperationException(
                                        "Invalid public facility drowndown value.");
                            }
                            break;

                        default:
                            throw new InvalidOperationException(
                                "Invalid item type dropdown value.");
                    }
                    lblResult.Text = string.Format("{0} result{1} found.", resultCount,
                        resultCount == 1 ? "" : "s");
                    lblResult.Visible = true;
                    mViewSearchResults.ActiveViewIndex = viewToDisplay;
                    gViewToDisplay.DataBind();
                }
            }
            catch (Exception ex)
            {
                lblError.Text = "Error: " + ex.Message;
                lblError.Visible = true;
            }
        }
    }
}